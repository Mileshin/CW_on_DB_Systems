CREATE package bus_deport_pkg is

  function addTypesBuses(
    new_brand varchar,
    new_model varchar,
    new_seats number) return number;
  procedure deleteTypesBuses(del_id in number);
  
   function addPOSITIONS(
    new_name varchar,
    new_abb varchar) return number;
  procedure deletePOSITIONS(del_id in number);

  function addPEOPLE(
    new_surname varchar,
    new_name varchar,
    new_middle_name varchar,
    new_DATE_OF_BIRTH DATE,
    new_POSITION varchar) return number;
  procedure deletePEOPLE(del_id in number);
  
  function addDRIVERS(
    new_id_people number,
    new_DATE_MEDICAL_CHECK_UP DATE,
    new_VIOLATIONS CLOB) return number;
  procedure deleteDRIVERS(del_id in number);
  
  function addDRIVERS_AND_PERSON(
    new_surname varchar,
    new_name varchar,
    new_middle_name varchar,
    new_DATE_OF_BIRTH DATE,
    new_DATE_MEDICAL_CHECK_UP DATE,
    new_VIOLATIONS CLOB) return number;
    
  function addBRIGADES(
    new_NAME varchar
    ) return number;
  procedure deleteBRIGADES(del_id in number);
  
  function addROUTES(
    START_STATION varchar,
    STOP_STATION varchar,
    LIST_OF_STATIONS CLOB
    ) return number;
  procedure deleteROUTES(del_id in number);

  function addSCHEDULE(
    new_ID_BRIGADE NUMBER,
    START_WORK_SHIFT DATE,
    STOP_WORK_SHIFT DATE
    ) return number;
  procedure deleteSCHEDULE(del_id in number);
  
  function addBUSES(
    new_NUMBER_PLATE varchar,
    new_BUS_TYPE NUMBER,
    new_BRIGADE NUMBER,
    new_ROUTE  NUMBER,
    new_LAST_VEHICLE_INSPECTION DATE
    ) return number;
  procedure deleteBUSES(del_id in number);
  
  function addBREAKDOWN(
    new_ID_BUS NUMBER,
    new_DATE_BREAKDOWN DATE,
    new_DESCRIPTION CLOB
    ) return number;
  procedure deleteBREAKDOWN(del_id in number);
  
  function addREPAIRS(
    new_ID_BREAKDOWN NUMBER,
    new_START_DATE DATE,
    new_END_DATE DATE,
    new_ID_MECHANIC NUMBER,
    new_CONCLUSION CLOB
    ) return number;
  procedure deleteREPAIRS(del_id in number);

end bus_deport_pkg;
/
