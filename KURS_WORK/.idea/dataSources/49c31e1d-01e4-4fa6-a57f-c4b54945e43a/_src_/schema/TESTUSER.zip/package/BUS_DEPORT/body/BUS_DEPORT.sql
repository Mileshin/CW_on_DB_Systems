CREATE package body bus_deport as
  procedure deleteTypesBuses(del_id in number) as
  begin
    delete from types_of_buses d where d.id = del_id;
  end;
end bus_deport;
/
